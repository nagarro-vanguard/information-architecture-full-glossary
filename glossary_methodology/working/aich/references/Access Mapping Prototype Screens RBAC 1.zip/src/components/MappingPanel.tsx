import { useEffect, useMemo, useState } from 'react'
import {
  DIRECTORY_GROUPS,
  findNode,
  nodePath,
  roleLabel,
  type DirectoryGroup,
  type Mapping,
  type RoleId,
} from '../data'
import { Btn, Callout, Field, inputCls } from './ui'
import { EffectiveDates, GroupSelect, GroupTypeahead, ImpactPreview, OrgTreePicker, RoleRadio } from './pieces'
import { impactOf, overlaps, type Scope } from '../lib/impact'

export default function MappingPanel({
  editing,
  mappings,
  idpOnline,
  onClose,
  onSave,
}: {
  editing: Mapping | null
  mappings: Mapping[]
  idpOnline: boolean
  onClose: () => void
  onSave: (m: Omit<Mapping, 'id'> & { id?: string }) => void
}) {
  const [group, setGroup] = useState<DirectoryGroup | null>(null)
  const [role, setRole] = useState<RoleId>('viewer')
  const [scopes, setScopes] = useState<Scope[]>([])
  const [from, setFrom] = useState('2026-08-06')
  const [to, setTo] = useState('')
  const [description, setDescription] = useState('')
  const [touched, setTouched] = useState(false)

  useEffect(() => {
    if (editing) {
      const g = DIRECTORY_GROUPS.find((x) => x.id === editing.groupId) ?? null
      setGroup(g?.deletedAtIdp ? null : g)
      setRole(editing.role)
      setScopes(editing.scopes)
      setFrom(editing.from)
      setTo(editing.to ?? '')
      setDescription(editing.note ?? '')
    } else {
      setGroup(null)
      setRole('viewer')
      setScopes([])
      setFrom('2026-08-06')
      setTo('')
      setDescription('')
    }
    setTouched(false)
  }, [editing])

  const impact = useMemo(() => impactOf(scopes, group?.members ?? 0), [scopes, group])
  const scopeNames = scopes.map((s) => findNode(s.nodeId)?.name ?? s.nodeId)

  const conflicts = useMemo(() => {
    if (!group) return []
    return mappings
      .filter((m) => m.groupId === group.id && m.id !== editing?.id && m.status !== 'inactive')
      .map((m) => ({ mapping: m, nodes: overlaps(m.scopes, scopes) }))
      .filter((c) => c.nodes.length > 0)
  }, [group, mappings, scopes, editing])

  const orphanedEdit = editing?.status === 'orphaned'
  const noScope = scopes.length === 0
  const canSave = !!group && !noScope && !!from && idpOnline

  const save = () => {
    setTouched(true)
    if (!canSave) return
    onSave({
      id: editing?.id,
      groupId: group!.id,
      role,
      scopes,
      from,
      to: to || undefined,
      status: from > '2026-08-06' ? 'scheduled' : 'active',
      note: description.trim() || undefined,
      modifiedBy: 'priya.raman@aurorahome.com',
      modifiedAt: new Date().toISOString(),
    })
  }

  const isEdit = !!editing

  return (
    <div className="fixed inset-0 z-40 flex justify-end">
      <div className="absolute inset-0 bg-[#16181d]/30 backdrop-blur-[1px]" onClick={onClose} />
      <aside className="relative flex h-full w-full max-w-[560px] flex-col border-l border-border bg-card shadow-2xl shadow-black/10">
        <header className="flex items-start justify-between gap-4 border-b border-border px-6 py-4">
          <div>
            <div className="label">{isEdit ? 'Edit mapping' : 'Add mapping'}</div>
            <h2 className="mt-1 text-[17px] font-semibold text-foreground">
              {isEdit ? 'Change who this group can see' : 'Grant a directory group access'}
            </h2>
            <p className="mt-0.5 text-[12px] text-muted-foreground">Changes apply immediately on save.</p>
          </div>
          <button onClick={onClose} className="text-[12.5px] text-muted-foreground hover:text-foreground">
            Close
          </button>
        </header>

        <div className="flex-1 overflow-y-auto px-6 py-5">
          <div className="grid gap-6">
            {orphanedEdit && (
              <Callout tone="danger" title="Group deleted at the identity provider">
                <span className="font-semibold">{DIRECTORY_GROUPS.find((g) => g.id === editing?.groupId)?.name}</span>{' '}
                no longer resolves in the directory. Pick a replacement group to restore this grant, or close and delete
                the mapping to retire it with an end date.
              </Callout>
            )}

            {isEdit ? (
              <Field label="Identity Group">
                <div className="flex items-center justify-between gap-3 rounded-card border border-border bg-muted px-3 py-2.5">
                  <div>
                    <div className="text-[13px] font-medium text-foreground">{group?.name ?? '—'}</div>
                    <div className="mt-0.5 text-[11px] text-muted-foreground">
                      {group ? `${group.members} members · ${group.source}` : 'Group deleted at IdP'}
                    </div>
                  </div>
                  <span className="rounded-md border border-border bg-card px-2 py-0.5 text-[11px] text-muted-foreground">
                    {group?.source ?? 'Azure AD'}
                  </span>
                </div>
              </Field>
            ) : (
              <>
                <Field label="Provider">
                  <div className="flex h-9 items-center gap-2 rounded-lg border border-border bg-muted px-3 text-[13px] text-secondary-foreground">
                    <span className="h-2 w-2 rounded-full bg-green-deep" />
                    Azure AD
                    <span className="ml-auto text-[11px] text-muted-foreground">Configured · read-only</span>
                  </div>
                </Field>
                <Field label="Identity Group" required hint="Resolved live against your IdP">
                  <GroupSelect value={group} onChange={setGroup} idpOnline={idpOnline} />
                </Field>
              </>
            )}

            <Field label="Role" required>
              <RoleRadio value={role} onChange={setRole} />
            </Field>

            <Field label="Scope" required hint="Select any node — toggle children per node">
              <OrgTreePicker scopes={scopes} onChange={setScopes} />
              {touched && noScope && (
                <p className="text-[12px] text-danger">
                  Select at least one org node — a mapping without scope grants nothing.
                </p>
              )}
            </Field>

            <EffectiveDates from={from} to={to} onFrom={setFrom} onTo={setTo} />

            <Field label="Description" hint="optional">
              <textarea
                className={`${inputCls} h-auto resize-none py-2.5`}
                rows={2}
                placeholder="Add context for this mapping — e.g. purpose, requestor, review date…"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </Field>

            <ImpactPreview
              ready={!!group && scopes.length > 0}
              members={impact.members}
              nodeCount={impact.nodeCount}
              childCount={impact.childCount}
              spend={impact.spend}
              scopeNames={scopeNames}
              roleLabel={roleLabel(role)}
            />

            {conflicts.map(({ mapping, nodes }) => (
              <Callout key={mapping.id} tone="warn" title="Overlapping scope">
                {group?.name} already has a <b>{roleLabel(mapping.role)}</b> mapping covering{' '}
                <span className="font-semibold">{nodes.map((n) => findNode(n)?.name).join(', ')}</span>. The broader role
                wins where they overlap.
              </Callout>
            ))}

            {(group?.members ?? 0) > 150 && (
              <Callout tone="info" title="Group-claim limit">
                Members of {group?.name} who belong to more than 6 groups will have claims delivered via the Graph
                overage path. Access is unaffected; sign-in adds roughly 200&nbsp;ms.
              </Callout>
            )}

            {scopes.length > 0 && (
              <div className="border-t border-border pt-4">
                <div className="label">Selected scope paths</div>
                <ul className="mt-2 grid gap-1">
                  {scopes.map((s) => (
                    <li key={s.nodeId} className="text-[12px] text-muted-foreground">
                      {nodePath(s.nodeId).join(' › ')}
                      {s.includeChildren && <span className="text-green-deep"> + all children</span>}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        <footer className="flex items-center justify-between gap-4 border-t border-border bg-muted px-6 py-4">
          <span className="text-[11.5px] text-muted-foreground">
            {canSave ? 'Change is written to the audit log on save.' : 'Identity Group and Scope are required.'}
          </span>
          <div className="flex gap-2">
            <Btn variant="outline" onClick={onClose}>
              Cancel
            </Btn>
            <Btn variant="primary" onClick={save} disabled={!canSave}>
              {isEdit ? 'Save changes' : 'Add mapping'}
            </Btn>
          </div>
        </footer>
      </aside>
    </div>
  )
}
