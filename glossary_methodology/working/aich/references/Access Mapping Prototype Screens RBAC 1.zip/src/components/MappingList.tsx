import { useMemo, useState } from 'react'
import {
  DIRECTORY_GROUPS,
  ORG_TREE,
  PEOPLE,
  ROLES,
  flattenTree,
  nodePath,
  roleLabel,
  stamp,
  type Mapping,
} from '../data'
import { Btn, Callout, Pill, Skeleton, inputCls } from './ui'
import { resolveScope } from '../lib/impact'

const COLS = ['Identity Group', 'Role', 'Scope', 'Last Modified', '']

export default function MappingList({
  mappings,
  loading,
  idpOnline,
  onAdd,
  onEdit,
  onDeactivate,
  onFix,
}: {
  mappings: Mapping[]
  loading: boolean
  idpOnline: boolean
  onAdd: () => void
  onEdit: (m: Mapping) => void
  onDeactivate: (m: Mapping) => void
  onFix: (m: Mapping) => void
}) {
  const [q, setQ] = useState('')
  const [role, setRole] = useState('all')
  const [node, setNode] = useState('all')
  const [deleteTarget, setDeleteTarget] = useState<Mapping | null>(null)

  const rows = useMemo(
    () =>
      mappings.filter((m) => {
        const g = DIRECTORY_GROUPS.find((x) => x.id === m.groupId)!
        if (q && !g.name.toLowerCase().includes(q.toLowerCase())) return false
        if (role !== 'all' && m.role !== role) return false
        if (node !== 'all' && !m.scopes.some((s) => s.nodeId === node)) return false
        return true
      }),
    [mappings, q, role, node],
  )

  const orphans = mappings.filter((m) => m.status === 'orphaned')
  const active = mappings.filter((m) => m.status === 'active')
  const peopleWithAccess = PEOPLE.filter((p) => active.some((m) => p.groups.includes(m.groupId))).length

  const hasFilters = q !== '' || role !== 'all' || node !== 'all'

  const resetFilters = () => {
    setQ('')
    setRole('all')
    setNode('all')
  }

  const select =
    'h-9 rounded-lg border border-border bg-card px-2 text-[12.5px] text-secondary-foreground focus:border-primary focus:outline-none'

  const confirmDelete = (m: Mapping) => {
    onDeactivate(m)
    setDeleteTarget(null)
  }

  return (
    <div className="grid gap-5">
      {!idpOnline && (
        <Callout tone="warn" title="Identity provider unreachable" action={<Pill kind="stale">Cached</Pill>}>
          Showing mappings cached at <span className="num">06 Aug 2026, 08:14</span>. Membership counts and group
          resolution are stale; editing is disabled until the connection recovers.
        </Callout>
      )}

      {orphans.length > 0 && (
        <Callout
          tone="danger"
          title={`${orphans.length} orphaned mapping${orphans.length === 1 ? '' : 's'}`}
          action={
            <Btn size="sm" variant="danger" onClick={() => onFix(orphans[0])}>
              Fix now
            </Btn>
          }
        >
          The directory group behind {orphans.length === 1 ? 'this mapping' : 'these mappings'} no longer exists at the
          identity provider. The grant is inert, but it stays on record until someone remaps or deletes it.
        </Callout>
      )}

      <section className="rounded-card border border-border bg-card">
        <header className="border-b border-border px-4 py-3">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-[15px] font-semibold text-foreground">Group Mappings</h2>
              <p className="mt-0.5 text-[12px] text-muted-foreground">
                Access always arrives through a directory group — never an individual.{' '}
                <span className="num">{active.length}</span> active · <span className="num">{peopleWithAccess}</span> people
                with access.
              </p>
            </div>
            <Btn variant="primary" onClick={onAdd}>
              Add mapping
            </Btn>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <input
              className={`${inputCls} flex-1`}
              placeholder="Search group name…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <select className={select} value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="all">All roles</option>
              {ROLES.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.label}
                </option>
              ))}
            </select>
            <select className={select} value={node} onChange={(e) => setNode(e.target.value)}>
              <option value="all">All scopes</option>
              {flattenTree(ORG_TREE).map(({ node: n, depth }) => (
                <option key={n.id} value={n.id}>
                  {'— '.repeat(depth)}
                  {n.name}
                </option>
              ))}
            </select>
            {hasFilters && (
              <button
                onClick={resetFilters}
                className="h-9 shrink-0 rounded-lg border border-border bg-card px-3 text-[12.5px] text-secondary-foreground transition-colors hover:border-[#c9c9c1] hover:text-foreground"
              >
                Reset filters
              </button>
            )}
          </div>
        </header>

        {loading ? (
          <div className="grid gap-4 px-4 py-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="grid grid-cols-[1.8fr_0.7fr_1.2fr_1fr_0.5fr] items-center gap-4">
                <Skeleton w="75%" />
                <Skeleton w="60%" />
                <Skeleton w="70%" />
                <Skeleton w="55%" />
                <Skeleton w="40%" />
              </div>
            ))}
          </div>
        ) : mappings.length === 0 ? (
          <EmptyState onAdd={onAdd} />
        ) : rows.length === 0 ? (
          <div className="px-6 py-16 text-center text-[13px] text-muted-foreground">
            No mappings match these filters.{' '}
            <button onClick={resetFilters} className="text-primary underline underline-offset-2 hover:no-underline">
              Clear filters
            </button>{' '}
            to widen the view.
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] border-collapse text-left">
                <thead>
                  <tr className="border-b border-border bg-muted">
                    {COLS.map((c) => (
                      <th key={c} className="label whitespace-nowrap px-4 py-2.5 font-semibold">
                        {c}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((m) => {
                    const g = DIRECTORY_GROUPS.find((x) => x.id === m.groupId)!
                    const orphan = m.status === 'orphaned'
                    const inactive = m.status === 'inactive'
                    return (
                      <tr
                        key={m.id}
                        className={`group border-b border-border/70 align-middle transition-colors last:border-0 hover:bg-muted ${
                          orphan ? 'hatch' : ''
                        }`}
                      >
                        <td className="px-4 py-3">
                          <div
                            className={`text-[13px] font-medium ${
                              orphan ? 'text-danger' : inactive ? 'text-muted-foreground' : 'text-foreground'
                            }`}
                          >
                            {g.name}
                          </div>
                          <div className="mt-0.5 text-[11px] text-muted-foreground">
                            {orphan
                              ? 'Deleted at identity provider'
                              : inactive
                                ? 'Access revoked'
                                : `${g.members} members · ${g.source}`}
                          </div>
                          {m.note && !orphan && (
                            <div className="mt-1 max-w-xs truncate text-[11px] italic text-muted-foreground">
                              {m.note}
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <RoleBadge role={m.role} />
                        </td>
                        <td className="px-4 py-3">
                          {m.scopes.map((s) => (
                            <div key={s.nodeId} className="text-[12.5px] text-secondary-foreground">
                              {nodePath(s.nodeId).slice(1).join(' › ') || 'Aurora (full org)'}
                              {s.includeChildren && (
                                <span className="ml-1 text-[11px] text-green-deep">+ children</span>
                              )}
                            </div>
                          ))}
                        </td>
                        <td className="px-4 py-3">
                          <div className="num text-[12px] text-secondary-foreground">{m.modifiedBy.split('@')[0]}</div>
                          <div className="num mt-0.5 text-[10.5px] text-muted-foreground">{stamp(m.modifiedAt)}</div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex justify-end gap-1 opacity-0 transition-opacity focus-within:opacity-100 group-hover:opacity-100">
                            {orphan ? (
                              <>
                                <Btn size="sm" variant="danger" onClick={() => onFix(m)}>
                                  Fix
                                </Btn>
                                <Btn size="sm" variant="outline" onClick={() => setDeleteTarget(m)}>
                                  Delete
                                </Btn>
                              </>
                            ) : (
                              <>
                                {!inactive && (
                                  <Btn size="sm" variant="outline" onClick={() => onEdit(m)} disabled={!idpOnline}>
                                    Edit
                                  </Btn>
                                )}
                                {m.status !== 'inactive' && (
                                  <Btn
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => setDeleteTarget(m)}
                                  >
                                    Delete
                                  </Btn>
                                )}
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
            <footer className="flex items-center justify-between border-t border-border px-4 py-2.5">
              <span className="text-[11.5px] text-muted-foreground">
                Showing <span className="num">{rows.length}</span> of <span className="num">{mappings.length}</span>{' '}
                mappings
              </span>
              <span className="text-[11.5px] text-muted-foreground">
                Mappings are never hard-deleted — deletion writes an end date so the audit trail survives.
              </span>
            </footer>
          </>
        )}
      </section>

      {deleteTarget && (
        <DeleteConfirmDialog
          mapping={deleteTarget}
          onConfirm={() => confirmDelete(deleteTarget)}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  )
}

function RoleBadge({ role }: { role: string }) {
  const styles: Record<string, string> = {
    viewer: 'text-info border-[#c9d8f8] bg-blue-tint',
    contributor: 'text-warn border-[#efd7ac] bg-warn-tint',
    'finops-admin': 'text-green-deep border-[#c5e5d9] bg-green-tint',
  }
  const labels: Record<string, string> = {
    viewer: 'Viewer',
    contributor: 'Contributor',
    'finops-admin': 'FinOps Admin',
  }
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium ${styles[role] ?? styles.viewer}`}
    >
      {labels[role] ?? role}
    </span>
  )
}

function DeleteConfirmDialog({
  mapping,
  onConfirm,
  onCancel,
}: {
  mapping: Mapping
  onConfirm: () => void
  onCancel: () => void
}) {
  const g = DIRECTORY_GROUPS.find((x) => x.id === mapping.groupId)!
  const affectedPeople = PEOPLE.filter((p) => p.groups.includes(mapping.groupId)).length
  const scopeLabel = mapping.scopes.map((s) => nodePath(s.nodeId).slice(1).join(' › ') || 'Aurora (full org)').join(', ')

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-[#16181d]/40 backdrop-blur-[2px]" onClick={onCancel} />
      <div className="relative w-full max-w-md rounded-card border border-border bg-card shadow-2xl shadow-black/15">
        <div className="border-b border-border px-6 py-4">
          <div className="label">Delete mapping</div>
          <h2 className="mt-1 text-[16px] font-semibold text-foreground">Revoke access for {g.name}?</h2>
        </div>
        <div className="px-6 py-5">
          <div className="rounded-card border border-[#f2cbc6] bg-danger-tint p-3.5">
            <p className="text-[12.5px] leading-relaxed text-danger">
              <strong>This will revoke access for all {affectedPeople > 0 ? affectedPeople : g.members} {affectedPeople === 1 ? 'user' : 'users'}</strong> currently
              in <strong>{g.name}</strong>. They will lose their <span className="capitalize">{roleLabel(mapping.role)}</span> access
              to <strong>{scopeLabel}</strong> immediately.
            </p>
          </div>
          <p className="mt-3 text-[12px] leading-relaxed text-muted-foreground">
            No data is permanently deleted. An end date is written to the audit log and this mapping will remain visible
            in the inactive state for compliance.
          </p>
        </div>
        <div className="flex justify-end gap-2 border-t border-border px-6 py-4">
          <Btn variant="outline" onClick={onCancel}>
            Cancel
          </Btn>
          <Btn variant="danger" onClick={onConfirm}>
            Delete mapping
          </Btn>
        </div>
      </div>
    </div>
  )
}

function EmptyState({ onAdd }: { onAdd: () => void }) {
  return (
    <div className="relative overflow-hidden">
      <div className="hatch absolute inset-0" />
      <div className="relative grid gap-5 px-8 py-16 text-center">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-[#f2cbc6] bg-danger-tint px-3 py-1 text-[11.5px] font-semibold text-danger">
            No mappings configured
          </span>
          <h2 className="mx-auto mt-4 max-w-lg text-[22px] font-semibold leading-snug text-foreground">
            Only the break-glass admin can sign in.
          </h2>
          <p className="mx-auto mt-2.5 max-w-md text-[13px] leading-relaxed text-secondary-foreground">
            Every other person in the directory — all <span className="num font-semibold text-danger">212</span> of them
            — is locked out of cost data until at least one Identity Group is mapped to a role and a scope.
          </p>
        </div>
        <div className="flex justify-center">
          <Btn variant="primary" onClick={onAdd}>
            Add the first mapping
          </Btn>
        </div>
      </div>
    </div>
  )
}
