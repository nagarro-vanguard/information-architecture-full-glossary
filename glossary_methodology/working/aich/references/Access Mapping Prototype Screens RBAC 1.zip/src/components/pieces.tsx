import { useMemo, useRef, useState } from 'react'
import {
  DIRECTORY_GROUPS,
  ORG_TREE,
  ROLES,
  money,
  type DirectoryGroup,
  type OrgNode,
  type RoleId,
} from '../data'
import { Field, Pill, Toggle, inputCls } from './ui'
import type { Scope } from '../lib/impact'

/* ── Group type-ahead (used in Edit mode for searching) ──────────────────── */
export function GroupTypeahead({
  value,
  onChange,
  idpOnline,
}: {
  value: DirectoryGroup | null
  onChange: (g: DirectoryGroup | null) => void
  idpOnline: boolean
}) {
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)
  const [resolving, setResolving] = useState(false)
  const timer = useRef<number | undefined>(undefined)

  const results = useMemo(() => {
    const needle = q.trim().toLowerCase()
    if (!needle) return []
    return DIRECTORY_GROUPS.filter((g) => !g.deletedAtIdp && g.name.toLowerCase().includes(needle)).slice(0, 6)
  }, [q])

  const search = (next: string) => {
    setQ(next)
    setOpen(true)
    setResolving(next.trim().length > 0)
    window.clearTimeout(timer.current)
    timer.current = window.setTimeout(() => setResolving(false), 320)
  }

  if (value) {
    return (
      <div className="flex items-start justify-between gap-3 rounded-card border border-border bg-muted px-3 py-2.5">
        <div className="min-w-0">
          <div className="text-[13px] font-medium text-foreground">{value.name}</div>
          <div className="mt-0.5 text-[11px] text-muted-foreground">{value.members} members · {value.source}</div>
        </div>
        <button
          onClick={() => { onChange(null); setQ('') }}
          className="text-[12px] text-muted-foreground hover:text-danger"
        >
          Clear
        </button>
      </div>
    )
  }

  return (
    <div className="relative">
      <input
        className={inputCls}
        placeholder={idpOnline ? 'Search group name…' : 'Directory unreachable — cannot resolve'}
        disabled={!idpOnline}
        value={q}
        onChange={(e) => search(e.target.value)}
        onFocus={() => setOpen(true)}
      />
      {open && q.trim() && (
        <div className="absolute z-30 mt-1 max-h-64 w-full overflow-auto rounded-card border border-border bg-card shadow-lg shadow-black/5">
          {resolving && <div className="px-3 py-2.5 text-[12px] text-muted-foreground">Resolving against IdP…</div>}
          {!resolving && results.length === 0 && (
            <div className="px-3 py-2.5 text-[12px] leading-relaxed text-muted-foreground">
              No group matches <span className="font-medium text-foreground">{q}</span>. Groups must exist in the
              directory — free text is not accepted.
            </div>
          )}
          {!resolving &&
            results.map((g) => (
              <button
                key={g.id}
                onClick={() => { onChange(g); setOpen(false) }}
                className="flex w-full items-center justify-between gap-3 border-b border-border/70 px-3 py-2.5 text-left last:border-0 hover:bg-muted"
              >
                <span className="min-w-0">
                  <span className="block text-[12.5px] font-medium text-foreground">{g.name}</span>
                  <span className="block text-[10.5px] text-muted-foreground">{g.members} members</span>
                </span>
                <span className="shrink-0 text-[10.5px] text-muted-foreground">{g.source}</span>
              </button>
            ))}
        </div>
      )}
    </div>
  )
}

/* ── Group select dropdown (used in Add mode) ────────────────────────────── */
export function GroupSelect({
  value,
  onChange,
  idpOnline,
}: {
  value: DirectoryGroup | null
  onChange: (g: DirectoryGroup | null) => void
  idpOnline: boolean
}) {
  const available = DIRECTORY_GROUPS.filter((g) => !g.deletedAtIdp)

  return (
    <select
      className={`${inputCls} cursor-pointer`}
      disabled={!idpOnline}
      value={value?.id ?? ''}
      onChange={(e) => {
        const g = available.find((x) => x.id === e.target.value) ?? null
        onChange(g)
      }}
    >
      <option value="">{idpOnline ? 'Select a group from Azure AD…' : 'Directory unreachable'}</option>
      {available.map((g) => (
        <option key={g.id} value={g.id}>
          {g.name} ({g.members} members)
        </option>
      ))}
    </select>
  )
}

/* ── Role radio with plain-language descriptions ─────────────────────────── */
export function RoleRadio({ value, onChange }: { value: RoleId; onChange: (r: RoleId) => void }) {
  return (
    <div className="grid gap-2">
      {ROLES.map((r) => {
        const on = r.id === value
        return (
          <button
            key={r.id}
            onClick={() => onChange(r.id)}
            className={`flex gap-3 rounded-card border px-3 py-2.5 text-left transition-colors ${
              on ? 'border-green bg-green-tint' : 'border-border bg-card hover:border-[#d3d3ca]'
            }`}
          >
            <span
              className={`mt-[3px] h-3.5 w-3.5 shrink-0 rounded-full border ${
                on ? 'border-green-deep bg-green-deep shadow-[inset_0_0_0_2.5px_#fff]' : 'border-[#c9c9c1] bg-white'
              }`}
            />
            <span>
              <span className={`block text-[13px] font-semibold ${on ? 'text-green-deep' : 'text-foreground'}`}>
                {r.label}
              </span>
              <span className="mt-0.5 block text-[12px] leading-snug text-muted-foreground">{r.description}</span>
            </span>
          </button>
        )
      })}
    </div>
  )
}

/* ── Org tree picker (shared with org setup) ─────────────────────────────── */
export function OrgTreePicker({ scopes, onChange }: { scopes: Scope[]; onChange: (s: Scope[]) => void }) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set(['root', 'retail']))

  const toggleNode = (id: string) => {
    const hit = scopes.find((s) => s.nodeId === id)
    onChange(hit ? scopes.filter((s) => s.nodeId !== id) : [...scopes, { nodeId: id, includeChildren: false }])
  }

  const render = (node: OrgNode, depth: number) => {
    const sel = scopes.find((s) => s.nodeId === node.id)
    const hasKids = !!node.children?.length
    const open = expanded.has(node.id)
    return (
      <div key={node.id}>
        <div
          className={`group flex items-center gap-2 border-b border-border/70 pr-2 transition-colors ${
            sel ? 'bg-green-tint' : 'hover:bg-muted'
          }`}
          style={{ paddingLeft: 8 + depth * 16 }}
        >
          <button
            onClick={() => {
              const next = new Set(expanded)
              open ? next.delete(node.id) : next.add(node.id)
              setExpanded(next)
            }}
            className={`w-3 shrink-0 text-[11px] text-muted-foreground hover:text-foreground ${
              hasKids ? '' : 'invisible'
            }`}
          >
            {open ? '−' : '+'}
          </button>
          <button onClick={() => toggleNode(node.id)} className="flex flex-1 items-center gap-2 py-1.5 text-left">
            <span
              className={`flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-[4px] border text-[9px] text-white ${
                sel ? 'border-green-deep bg-green-deep' : 'border-[#c9c9c1] bg-white'
              }`}
            >
              {sel ? '✓' : ''}
            </span>
            <span className={`text-[12.5px] ${sel ? 'text-green-deep' : 'text-foreground'}`}>{node.name}</span>
            <span className="text-[10.5px] text-muted-foreground">{node.kind}</span>
            <span className="num ml-auto text-[11px] text-muted-foreground">{money(node.monthlySpend)}/mo</span>
          </button>
          {sel && hasKids && (
            <span className="flex shrink-0 items-center gap-1.5">
              <span className="text-[10.5px] text-muted-foreground">+ children</span>
              <Toggle
                on={sel.includeChildren}
                label={`Include all child nodes of ${node.name}`}
                onChange={(v) => onChange(scopes.map((s) => (s.nodeId === node.id ? { ...s, includeChildren: v } : s)))}
              />
            </span>
          )}
        </div>
        {open && node.children?.map((c) => render(c, depth + 1))}
      </div>
    )
  }

  return (
    <div className="max-h-64 overflow-auto rounded-card border border-border bg-card">{render(ORG_TREE, 0)}</div>
  )
}

/* ── Effective date pair ─────────────────────────────────────────────────── */
export function EffectiveDates({
  from,
  to,
  onFrom,
  onTo,
}: {
  from: string
  to: string
  onFrom: (v: string) => void
  onTo: (v: string) => void
}) {
  return (
    <div className="grid grid-cols-2 gap-3">
      <Field label="Effective from" required>
        <input type="date" className={inputCls} value={from} onChange={(e) => onFrom(e.target.value)} />
      </Field>
      <Field label="Effective to" hint="optional">
        <input type="date" className={inputCls} value={to} onChange={(e) => onTo(e.target.value)} />
      </Field>
    </div>
  )
}

/* ── Impact preview card ─────────────────────────────────────────────────
   The single component that stops a mis-scoped mapping from being saved. */
export function ImpactPreview({
  members,
  nodeCount,
  childCount,
  spend,
  scopeNames,
  roleLabel,
  ready,
}: {
  members: number
  nodeCount: number
  childCount: number
  spend: number
  scopeNames: string[]
  roleLabel: string
  ready: boolean
}) {
  const heavy = spend > 150_000 || nodeCount > 8

  if (!ready) {
    return (
      <div className="rounded-card border border-dashed border-border p-4 text-center">
        <div className="label">Impact preview</div>
        <p className="mt-2 text-[12.5px] text-muted-foreground">
          Pick a group and at least one node to see who this actually grants access to.
        </p>
      </div>
    )
  }

  return (
    <div
      className={`overflow-hidden rounded-card border ${
        heavy ? 'border-[#efd7ac] bg-warn-tint' : 'border-[#c5e5d9] bg-green-tint'
      }`}
    >
      <div className="flex items-center justify-between border-b border-black/5 px-4 py-2">
        <span className="label">Impact preview</span>
        {heavy && <Pill kind="stale">Broad grant</Pill>}
      </div>
      <div className="px-4 py-4">
        <p className="text-[14.5px] leading-relaxed text-foreground">
          This grants <b className="num text-green-deep">{members}</b> users{' '}
          <b className="text-green-deep">{roleLabel.toLowerCase()}</b> access to{' '}
          <b className="text-green-deep">{scopeNames.join(', ')}</b>
          {childCount > 0 && (
            <>
              {' '}
              and <b className="num text-green-deep">{childCount}</b> child node{childCount === 1 ? '' : 's'}
            </>
          )}
          , covering approximately <b className="num text-green-deep">{money(spend)}/month</b> of cost.
        </p>
        <div className="mt-4 grid grid-cols-3 gap-2">
          {[
            ['Users', String(members)],
            ['Nodes', String(nodeCount)],
            ['Monthly cost', money(spend)],
          ].map(([k, v]) => (
            <div key={k} className="rounded-lg border border-border bg-card px-3 py-2.5">
              <div className="label">{k}</div>
              <div className="num mt-1 text-[17px] font-semibold text-foreground">{v}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ── Export control ──────────────────────────────────────────────────────── */
export function ExportControl({ onExport }: { onExport: (fmt: 'CSV' | 'PDF') => void }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="inline-flex h-8 items-center gap-2 rounded-full border border-border bg-card px-3.5 text-[12.5px] text-secondary-foreground transition-colors hover:border-[#d3d3ca] hover:text-foreground"
      >
        Export ▾
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 z-20 mt-1.5 w-64 rounded-card border border-border bg-card p-1 shadow-lg shadow-black/10">
            {(['CSV', 'PDF'] as const).map((f) => (
              <button
                key={f}
                onClick={() => {
                  onExport(f)
                  setOpen(false)
                }}
                className="block w-full rounded-lg px-3 py-2 text-left hover:bg-muted"
              >
                <span className="text-[13px] font-medium text-foreground">Download .{f.toLowerCase()}</span>
                <span className="mt-0.5 block text-[11.5px] leading-snug text-muted-foreground">
                  Signed with timestamp, Hub version and your identity.
                </span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
