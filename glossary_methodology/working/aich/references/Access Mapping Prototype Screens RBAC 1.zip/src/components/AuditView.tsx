import { useMemo, useState } from 'react'
import {
  CURRENT_USER,
  DIRECTORY_GROUPS,
  GROUP_CLAIM_LIMIT,
  HUB_VERSION,
  ORG_TREE,
  PEOPLE,
  ROLES,
  findNode,
  flattenTree,
  money,
  nodePath,
  roleLabel,
  shortDate,
  type Mapping,
  type Person,
  type RoleId,
} from '../data'
import { Btn, Callout, Pill } from './ui'
import { ExportControl } from './pieces'
import { isLive, resolveScope } from '../lib/impact'

type Grant = { nodeId: string; role: RoleId; via: string; from: string; to?: string }

function grantsFor(person: Person, mappings: Mapping[], asOf: string): Grant[] {
  const out: Grant[] = []
  for (const m of mappings) {
    if (!person.groups.includes(m.groupId)) continue
    if (!isLive(m, asOf)) continue
    const g = DIRECTORY_GROUPS.find((x) => x.id === m.groupId)!
    for (const nodeId of resolveScope(m.scopes)) {
      out.push({ nodeId, role: m.role, via: g.name, from: m.from, to: m.to })
    }
  }
  return out
}

export default function AuditView({ mappings }: { mappings: Mapping[] }) {
  const [pivot, setPivot] = useState<'person' | 'node'>('person')
  const [asOf, setAsOf] = useState('2026-08-06')
  const [q, setQ] = useState('')
  const [openRow, setOpenRow] = useState<string | null>('priya.raman@aurorahome.com')
  const [nodeId, setNodeId] = useState('retail')
  const [toast, setToast] = useState<string | null>(null)

  const historical = asOf !== '2026-08-06'

  const people = useMemo(
    () =>
      PEOPLE.filter(
        (p) => p.name.toLowerCase().includes(q.toLowerCase()) || p.email.toLowerCase().includes(q.toLowerCase()),
      ),
    [q],
  )

  const node = findNode(nodeId)!
  const byNode = useMemo(() => {
    const buckets: Record<string, { person: Person; via: string }[]> = {}
    for (const p of PEOPLE) {
      for (const g of grantsFor(p, mappings, asOf)) {
        if (g.nodeId !== nodeId) continue
        buckets[g.role] ??= []
        if (!buckets[g.role].some((e) => e.person.email === p.email)) buckets[g.role].push({ person: p, via: g.via })
      }
    }
    return buckets
  }, [mappings, nodeId, asOf])

  const overLimit = PEOPLE.filter((p) => p.groups.length > GROUP_CLAIM_LIMIT)

  const doExport = (fmt: 'CSV' | 'PDF') =>
    setToast(
      `access-matrix_${asOf}.${fmt.toLowerCase()} — generated ${new Date().toLocaleString('en-GB')} · Hub ${HUB_VERSION} · ${CURRENT_USER}`,
    )

  return (
    <div className="grid gap-5">
      {historical && (
        <Callout tone="info" title="Historical view">
          Showing effective access as it stood on <b>{shortDate(asOf)}</b>, reconstructed from the mapping ledger.
          Editing is unavailable in a historical view.
        </Callout>
      )}

      {overLimit.length > 0 && (
        <Callout tone="info" title="Group-claim overage">
          {overLimit.length} {overLimit.length === 1 ? 'person belongs' : 'people belong'} to more than{' '}
          {GROUP_CLAIM_LIMIT} directory groups ({overLimit.map((p) => p.name).join(', ')}). Their claims resolve through
          the directory Graph API instead of the sign-in token — informational only, access is identical.
        </Callout>
      )}

      {toast && (
        <Callout
          tone="ok"
          title="Export ready"
          action={
            <Btn size="sm" variant="outline" onClick={() => setToast(null)}>
              Dismiss
            </Btn>
          }
        >
          <span className="num text-[11.5px]">{toast}</span>
        </Callout>
      )}

      <section className="rounded-card border border-border bg-card">
        <header className="flex flex-wrap items-center gap-3 border-b border-border px-4 py-3">
          <div className="mr-auto">
            <h2 className="text-[15px] font-semibold text-foreground">Effective access</h2>
            <p className="mt-0.5 text-[12px] text-muted-foreground">
              Every grant names the group that produced it — the audit question is “why”, not “what”.
            </p>
          </div>
          <div className="flex gap-1 rounded-full border border-border bg-muted p-0.5">
            {(['person', 'node'] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPivot(p)}
                className={`h-7 rounded-full px-3.5 text-[12.5px] font-medium transition-colors ${
                  pivot === p
                    ? 'bg-green-deep text-white shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                By {p}
              </button>
            ))}
          </div>
          {pivot === 'person' ? (
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search people…"
              className="h-8 w-56 rounded-lg border border-border bg-card px-3 text-[12.5px] text-foreground placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none"
            />
          ) : (
            <select
              value={nodeId}
              onChange={(e) => setNodeId(e.target.value)}
              className="h-8 rounded-lg border border-border bg-card px-2 text-[12.5px] text-secondary-foreground focus:border-primary focus:outline-none"
            >
              {flattenTree(ORG_TREE).map(({ node: n, depth }) => (
                <option key={n.id} value={n.id}>
                  {'— '.repeat(depth)}
                  {n.name}
                </option>
              ))}
            </select>
          )}
          <label className="flex h-8 items-center gap-2 rounded-full border border-border bg-card px-3">
            <span className="text-[12px] text-muted-foreground">As of</span>
            <input
              type="date"
              value={asOf}
              onChange={(e) => setAsOf(e.target.value)}
              className="num bg-transparent text-[12px] text-foreground focus:outline-none"
            />
          </label>
          <ExportControl onExport={doExport} />
        </header>

        {pivot === 'person' ? (
          <div>
            {people.length === 0 && (
              <div className="px-6 py-14 text-center text-[13px] text-muted-foreground">No person matches “{q}”.</div>
            )}
            {people.map((p) => {
              const grants = grantsFor(p, mappings, asOf)
              const open = openRow === p.email
              const roles = [...new Set(grants.map((g) => g.role))]
              return (
                <div key={p.email} className="border-b border-border/70 last:border-0">
                  <button
                    onClick={() => setOpenRow(open ? null : p.email)}
                    className="flex w-full items-center gap-4 px-4 py-3 text-left transition-colors hover:bg-muted"
                  >
                    <span className="w-3 text-[12px] text-muted-foreground">{open ? '−' : '+'}</span>
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-blue-tint text-[11px] font-semibold text-primary">
                      {p.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-[13px] font-medium text-foreground">{p.name}</span>
                      <span className="block text-[11.5px] text-muted-foreground">
                        {p.email} · {p.title}
                      </span>
                    </span>
                    <span className="hidden gap-1.5 sm:flex">
                      {roles.length === 0 ? (
                        <Pill kind="inactive">No access</Pill>
                      ) : (
                        roles.map((r) => (
                          <Pill key={r} kind="active">
                            {roleLabel(r)}
                          </Pill>
                        ))
                      )}
                    </span>
                    <span className="num w-24 shrink-0 text-right text-[11.5px] text-muted-foreground">
                      {grants.length} node{grants.length === 1 ? '' : 's'}
                    </span>
                  </button>
                  {open && (
                    <div className="bg-muted px-4 pb-4 pl-[60px]">
                      {grants.length === 0 ? (
                        <p className="py-3 text-[12.5px] text-muted-foreground">
                          No effective access on {shortDate(asOf)}.
                        </p>
                      ) : (
                        <table className="w-full text-left">
                          <thead>
                            <tr>
                              {['Node', 'Role', 'Granted by group', 'Effective'].map((c) => (
                                <th key={c} className="label pb-1.5 pt-2 font-semibold">
                                  {c}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {grants.map((g, i) => (
                              <tr key={i} className="border-t border-border">
                                <td className="py-1.5 pr-4 text-[12px] text-secondary-foreground">
                                  {nodePath(g.nodeId).slice(1).join(' / ') || 'Aurora'}
                                </td>
                                <td className="py-1.5 pr-4 text-[12px] text-secondary-foreground">
                                  {roleLabel(g.role)}
                                </td>
                                <td className="num py-1.5 pr-4 text-[11.5px] font-medium text-green-deep">{g.via}</td>
                                <td className="num py-1.5 text-[11px] text-muted-foreground">
                                  {shortDate(g.from)} → {g.to ? shortDate(g.to) : 'open'}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        ) : (
          <div className="grid gap-4 p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-3 rounded-card border border-border bg-muted px-4 py-3">
              <div>
                <div className="label">{nodePath(nodeId).join(' / ')}</div>
                <div className="mt-1 text-[17px] font-semibold text-foreground">{node.name}</div>
              </div>
              <div className="num text-[12px] text-muted-foreground">
                {money(node.monthlySpend)}/mo · {node.headcount} people in unit
              </div>
            </div>
            <div className="grid gap-3 lg:grid-cols-3">
              {ROLES.map((r) => {
                const entries = byNode[r.id] ?? []
                return (
                  <div key={r.id} className="overflow-hidden rounded-card border border-border">
                    <div className="flex items-center justify-between border-b border-border bg-muted px-3 py-2">
                      <span className="text-[13px] font-semibold text-foreground">{r.label}</span>
                      <span className="num rounded-full bg-green-tint px-2 py-0.5 text-[11.5px] font-semibold text-green-deep">
                        {entries.length}
                      </span>
                    </div>
                    {entries.length === 0 ? (
                      <p className="px-3 py-7 text-center text-[12px] text-muted-foreground">Nobody</p>
                    ) : (
                      <ul>
                        {entries.map((e) => (
                          <li key={e.person.email} className="border-b border-border/70 px-3 py-2 last:border-0">
                            <div className="text-[12.5px] text-foreground">{e.person.name}</div>
                            <div className="mt-0.5 text-[11px] text-muted-foreground">
                              via <span className="num font-medium text-green-deep">{e.via}</span>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        )}

        <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-border px-4 py-2.5">
          <span className="text-[11.5px] text-muted-foreground">
            Read-only view · no user management happens here.
          </span>
          <span className="num text-[11px] text-muted-foreground">
            Hub {HUB_VERSION} · viewer {CURRENT_USER}
          </span>
        </footer>
      </section>
    </div>
  )
}
