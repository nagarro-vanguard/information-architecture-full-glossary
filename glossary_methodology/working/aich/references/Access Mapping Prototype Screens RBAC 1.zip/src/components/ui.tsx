import type { ReactNode } from 'react'

export function Btn({
  children,
  onClick,
  variant = 'ghost',
  size = 'md',
  disabled,
  title,
  type = 'button',
}: {
  children: ReactNode
  onClick?: () => void
  variant?: 'primary' | 'ghost' | 'outline' | 'danger'
  size?: 'sm' | 'md'
  disabled?: boolean
  title?: string
  type?: 'button' | 'submit'
}) {
  const base =
    'inline-flex items-center gap-2 font-medium rounded-lg transition-colors duration-150 disabled:opacity-40 disabled:cursor-not-allowed whitespace-nowrap'
  const sizes = { sm: 'text-[12px] px-2.5 h-7', md: 'text-[13px] px-3.5 h-9' }
  const variants = {
    primary: 'bg-green-deep text-white hover:bg-[#0c5c44] shadow-sm',
    ghost: 'text-secondary-foreground hover:bg-secondary hover:text-foreground',
    outline: 'border border-border bg-card text-secondary-foreground hover:border-[#c9c9c1] hover:text-foreground',
    danger: 'border border-[#f0c4bf] bg-danger-tint text-danger hover:bg-[#fbe0dd]',
  }
  return (
    <button
      type={type}
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={`${base} ${sizes[size]} ${variants[variant]}`}
    >
      {children}
    </button>
  )
}

const STATUS_STYLE: Record<string, string> = {
  active: 'text-green-deep border-[#c5e5d9] bg-green-tint',
  scheduled: 'text-info border-[#c9d8f8] bg-blue-tint',
  inactive: 'text-muted-foreground border-border bg-secondary',
  orphaned: 'text-danger border-[#f2cbc6] bg-danger-tint',
  stale: 'text-warn border-[#efd7ac] bg-warn-tint',
}

export function Pill({ kind, children }: { kind: keyof typeof STATUS_STYLE | string; children: ReactNode }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-medium capitalize ${
        STATUS_STYLE[kind] ?? STATUS_STYLE.inactive
      }`}
    >
      {children}
    </span>
  )
}

export function Field({
  label,
  hint,
  children,
  required,
}: {
  label: string
  hint?: string
  children: ReactNode
  required?: boolean
}) {
  return (
    <div className="grid gap-2">
      <div className="flex items-baseline justify-between gap-4">
        <span className="label">
          {label}
          {required && <span className="text-danger"> *</span>}
        </span>
        {hint && <span className="text-[11.5px] text-muted-foreground">{hint}</span>}
      </div>
      {children}
    </div>
  )
}

export const inputCls =
  'w-full bg-card border border-border rounded-lg px-3 h-9 text-[13px] text-foreground placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none transition-colors'

export function Callout({
  tone,
  title,
  children,
  action,
}: {
  tone: 'danger' | 'warn' | 'info' | 'ok'
  title: string
  children?: ReactNode
  action?: ReactNode
}) {
  const tones = {
    danger: 'border-[#f2cbc6] bg-danger-tint text-danger',
    warn: 'border-[#efd7ac] bg-warn-tint text-warn',
    info: 'border-[#c9d8f8] bg-blue-tint text-info',
    ok: 'border-[#c5e5d9] bg-green-tint text-green-deep',
  }
  return (
    <div className={`rounded-card border p-3.5 ${tones[tone]}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[12px] font-semibold">{title}</div>
          {children && (
            <div className="mt-1 text-[12.5px] leading-relaxed text-secondary-foreground">{children}</div>
          )}
        </div>
        {action}
      </div>
    </div>
  )
}

export function Skeleton({ w = '100%', h = 12 }: { w?: string | number; h?: number }) {
  return (
    <div
      className="animate-pulse rounded bg-secondary"
      style={{ width: typeof w === 'number' ? `${w}px` : w, height: h }}
    />
  )
}

export function Toggle({
  on,
  onChange,
  label,
}: {
  on: boolean
  onChange: (v: boolean) => void
  label?: string
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={`relative h-4 w-7 shrink-0 rounded-full border transition-colors ${
        on ? 'border-green bg-green' : 'border-border bg-secondary'
      }`}
    >
      <span
        className={`absolute top-[1px] h-[12px] w-[12px] rounded-full transition-all ${
          on ? 'left-[13px] bg-white' : 'left-[1px] bg-[#b8bcc2]'
        }`}
      />
    </button>
  )
}

/* Chip used in the top bar — matches the pill controls on the overview screen. */
export function Chip({
  children,
  onClick,
  active,
}: {
  children: ReactNode
  onClick?: () => void
  active?: boolean
}) {
  const Tag = onClick ? 'button' : 'div'
  return (
    <Tag
      onClick={onClick}
      className={`inline-flex h-8 items-center gap-2 rounded-full border px-3 text-[12.5px] transition-colors ${
        active
          ? 'border-[#c5e5d9] bg-green-tint text-green-deep'
          : 'border-border bg-card text-secondary-foreground hover:border-[#d3d3ca]'
      }`}
    >
      {children}
    </Tag>
  )
}
