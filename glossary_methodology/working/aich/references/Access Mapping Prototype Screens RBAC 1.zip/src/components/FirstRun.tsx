import { useState } from 'react'
import { DIRECTORY_GROUPS, money } from '../data'
import { Btn, Callout, Pill } from './ui'

const STEPS = ['Connect IdP', 'Admin group', 'Confirm impact', 'Break-glass'] as const

export default function FirstRun({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(0)
  const [source, setSource] = useState<'Azure AD' | 'Okta' | null>(null)
  const [groupId, setGroupId] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const group = DIRECTORY_GROUPS.find((g) => g.id === groupId)

  const canNext = [source !== null, groupId !== null, true, true][step]

  return (
    <div className="mx-auto max-w-2xl">
      <div className="label">First-run setup</div>
      <h1 className="mt-1.5 text-[24px] font-semibold tracking-tight text-foreground">Nobody can sign in yet.</h1>
      <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">
        Four steps. At the end you get one break-glass credential, shown once.
      </p>

      <ol className="mt-5 grid grid-cols-4 gap-2">
        {STEPS.map((s, i) => (
          <li
            key={s}
            className={`rounded-card border px-3 py-2 ${
              i === step ? 'border-green bg-green-tint' : 'border-border bg-card'
            }`}
          >
            <div
              className={`num text-[11px] font-semibold ${i < step ? 'text-green-deep' : 'text-muted-foreground'}`}
            >
              {i < step ? '✓ done' : `0${i + 1}`}
            </div>
            <div className={`mt-0.5 text-[12px] ${i === step ? 'text-green-deep' : 'text-secondary-foreground'}`}>
              {s}
            </div>
          </li>
        ))}
      </ol>

      <div className="mt-4 rounded-card border border-border bg-card p-5">
        {step === 0 && (
          <div className="grid gap-3">
            <p className="text-[13px] text-secondary-foreground">Choose the directory this Hub will trust.</p>
            {(['Azure AD', 'Okta'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setSource(s)}
                className={`flex items-center justify-between rounded-card border px-4 py-3 text-left transition-colors ${
                  source === s ? 'border-green bg-green-tint' : 'border-border hover:border-[#d3d3ca]'
                }`}
              >
                <span className="text-[13.5px] font-medium text-foreground">{s}</span>
                <span className="num text-[11px] text-muted-foreground">
                  {s === 'Azure AD' ? 'OIDC · tenant aurora.onmicrosoft.com' : 'SAML 2.0 · aurora.okta.com'}
                </span>
              </button>
            ))}
          </div>
        )}

        {step === 1 && (
          <div className="grid gap-3">
            <p className="text-[13px] text-secondary-foreground">
              Which directory group holds the people who will administer the Hub?
            </p>
            {DIRECTORY_GROUPS.filter((g) => !g.deletedAtIdp && g.source === source)
              .slice(0, 4)
              .map((g) => (
                <button
                  key={g.id}
                  onClick={() => setGroupId(g.id)}
                  className={`flex items-center justify-between rounded-card border px-4 py-2.5 text-left transition-colors ${
                    groupId === g.id ? 'border-green bg-green-tint' : 'border-border hover:border-[#d3d3ca]'
                  }`}
                >
                  <span className="num text-[12.5px] text-foreground">{g.name}</span>
                  <span className="num text-[11px] text-muted-foreground">{g.members} members</span>
                </button>
              ))}
          </div>
        )}

        {step === 2 && group && (
          <div className="grid gap-4">
            <div className="rounded-card border border-[#c5e5d9] bg-green-tint p-4">
              <div className="label">Impact preview</div>
              <p className="mt-2 text-[14.5px] leading-relaxed text-foreground">
                This grants <b className="num text-green-deep">{group.members}</b> users{' '}
                <b className="text-green-deep">node owner</b> access to <b className="text-green-deep">Aurora</b> and{' '}
                <b className="num text-green-deep">17</b> child nodes, covering approximately{' '}
                <b className="num text-green-deep">{money(385_628)}/month</b> of cost.
              </p>
            </div>
            <Callout tone="warn" title="Root scope">
              Administrators see every node and every figure. If that is broader than intended, go back and pick a
              narrower group — you can add more mappings afterwards.
            </Callout>
          </div>
        )}

        {step === 3 && (
          <div className="grid gap-4">
            <Callout tone="danger" title="Shown once — never again">
              Store this in your password manager now. It is the only way in if the directory is unavailable.
            </Callout>
            <div className="rounded-card border border-border bg-muted p-4">
              <div className="label">Break-glass credential</div>
              <div className="num mt-2 text-[13px] text-foreground">breakglass@aurora-hub.local</div>
              <div className="num mt-1 text-[18px] font-semibold tracking-[0.04em] text-primary">
                7QhT-2Vnx-Ld93-Rk5M-Ub0e
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Btn size="sm" variant="outline" onClick={() => setCopied(true)}>
                  {copied ? 'Copied' : 'Copy'}
                </Btn>
                <Pill kind="orphaned">Sign-in alerts every admin</Pill>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between">
        <Btn variant="ghost" onClick={() => (step === 0 ? onDone() : setStep(step - 1))}>
          {step === 0 ? 'Skip setup' : 'Back'}
        </Btn>
        <Btn variant="primary" disabled={!canNext} onClick={() => (step === 3 ? onDone() : setStep(step + 1))}>
          {step === 3 ? 'Finish — go to mappings' : 'Continue'}
        </Btn>
      </div>
    </div>
  )
}
