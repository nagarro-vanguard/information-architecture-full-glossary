export type Source = 'Azure AD' | 'Okta'
export type RoleId = 'viewer' | 'contributor' | 'finops-admin'
export type Status = 'active' | 'scheduled' | 'inactive' | 'orphaned'

export const ROLES: {
  id: RoleId
  label: string
  description: string
}[] = [
  {
    id: 'viewer',
    label: 'Viewer',
    description: 'Read-only access. Can view cost, usage, and budget figures within their scope. Cannot edit any value or process data.',
  },
  {
    id: 'contributor',
    label: 'Contributor',
    description: 'View plus edit values and process data, restricted to their predefined scope node. Cannot manage access or configure org settings.',
  },
  {
    id: 'finops-admin',
    label: 'FinOps Admin',
    description: 'Full control across all nodes in the org tree. Can manage budgets, approve commitments, and configure group mappings.',
  },
]

export const roleLabel = (id: string) => ROLES.find((r) => r.id === id)?.label ?? id

export type OrgNode = {
  id: string
  name: string
  kind: string
  monthlySpend: number
  headcount: number
  children?: OrgNode[]
}

export const ORG_TREE: OrgNode = {
  id: 'root',
  name: 'Aurora',
  kind: 'Root',
  monthlySpend: 385_628,
  headcount: 212,
  children: [
    {
      id: 'retail',
      name: 'Retail',
      kind: 'Division',
      monthlySpend: 183_600,
      headcount: 34,
      children: [
        { id: 'retail-stores', name: 'Store Systems', kind: 'Team', monthlySpend: 78_200, headcount: 12 },
        { id: 'retail-ecom', name: 'E-commerce', kind: 'Team', monthlySpend: 52_400, headcount: 9 },
        { id: 'retail-pos', name: 'Point of Sale', kind: 'Team', monthlySpend: 24_900, headcount: 5 },
        { id: 'retail-loyalty', name: 'Loyalty Platform', kind: 'Team', monthlySpend: 13_100, headcount: 4 },
        { id: 'retail-supply', name: 'Supply Chain', kind: 'Team', monthlySpend: 9_600, headcount: 3 },
        { id: 'retail-labs', name: 'Retail Labs', kind: 'Team', monthlySpend: 5_400, headcount: 1 },
      ],
    },
    {
      id: 'wholesale',
      name: 'Wholesale',
      kind: 'Division',
      monthlySpend: 61_400,
      headcount: 41,
      children: [
        { id: 'wholesale-edi', name: 'EDI Gateway', kind: 'Team', monthlySpend: 35_200, headcount: 8 },
        { id: 'wholesale-pricing', name: 'Trade Pricing', kind: 'Team', monthlySpend: 26_200, headcount: 6 },
      ],
    },
    {
      id: 'corporate',
      name: 'Corporate',
      kind: 'Division',
      monthlySpend: 84_628,
      headcount: 88,
      children: [
        { id: 'corp-finance', name: 'Finance', kind: 'Department', monthlySpend: 43_900, headcount: 22 },
        { id: 'corp-hr', name: 'People Ops', kind: 'Department', monthlySpend: 21_800, headcount: 14 },
        { id: 'corp-legal', name: 'Legal', kind: 'Department', monthlySpend: 18_928, headcount: 9 },
      ],
    },
    {
      id: 'digital',
      name: 'Digital Platform',
      kind: 'Division',
      monthlySpend: 56_000,
      headcount: 49,
      children: [
        { id: 'digital-data', name: 'Data Platform', kind: 'Team', monthlySpend: 34_100, headcount: 11 },
        { id: 'digital-sre', name: 'SRE', kind: 'Team', monthlySpend: 21_900, headcount: 7 },
      ],
    },
  ],
}

export const flattenTree = (node: OrgNode = ORG_TREE, depth = 0): { node: OrgNode; depth: number }[] => [
  { node, depth },
  ...(node.children ?? []).flatMap((c) => flattenTree(c, depth + 1)),
]

export const findNode = (id: string, node: OrgNode = ORG_TREE): OrgNode | undefined => {
  if (node.id === id) return node
  for (const child of node.children ?? []) {
    const hit = findNode(id, child)
    if (hit) return hit
  }
  return undefined
}

export const descendantsOf = (id: string): OrgNode[] => {
  const node = findNode(id)
  if (!node) return []
  return flattenTree(node).slice(1).map((e) => e.node)
}

export const nodePath = (id: string): string[] => {
  const walk = (n: OrgNode, trail: string[]): string[] | null => {
    const next = [...trail, n.name]
    if (n.id === id) return next
    for (const c of n.children ?? []) {
      const hit = walk(c, next)
      if (hit) return hit
    }
    return null
  }
  return walk(ORG_TREE, []) ?? []
}

export type DirectoryGroup = {
  id: string
  name: string
  source: Source
  members: number
  deletedAtIdp?: boolean
}

export const DIRECTORY_GROUPS: DirectoryGroup[] = [
  { id: 'g1', name: 'All FinOps Users', source: 'Azure AD', members: 212 },
  { id: 'g2', name: 'Finance Leadership', source: 'Azure AD', members: 22 },
  { id: 'g3', name: 'Retail Analysts', source: 'Azure AD', members: 34 },
  { id: 'g4', name: 'E-commerce Engineering', source: 'Azure AD', members: 9 },
  { id: 'g5', name: 'Wholesale Operations', source: 'Azure AD', members: 6 },
  { id: 'g6', name: 'KPMG Contractor Team', source: 'Azure AD', members: 11 },
  { id: 'g7', name: 'SRE On-Call', source: 'Azure AD', members: 7 },
  { id: 'g8', name: 'Legal E-Discovery', source: 'Azure AD', members: 9 },
  { id: 'g9', name: 'Platform Engineering', source: 'Azure AD', members: 0, deletedAtIdp: true },
]

export type Mapping = {
  id: string
  groupId: string
  role: RoleId
  scopes: { nodeId: string; includeChildren: boolean }[]
  from: string
  to?: string
  status: Status
  note?: string
  modifiedBy: string
  modifiedAt: string
}

export const INITIAL_MAPPINGS: Mapping[] = [
  {
    id: 'm1',
    groupId: 'g2',
    role: 'contributor',
    scopes: [{ nodeId: 'corp-finance', includeChildren: true }],
    from: '2025-01-06',
    status: 'active',
    note: 'Finance controllers — full edit rights within their division.',
    modifiedBy: 'priya.raman@aurorahome.com',
    modifiedAt: '2026-05-14T09:12:00Z',
  },
  {
    id: 'm2',
    groupId: 'g3',
    role: 'viewer',
    scopes: [{ nodeId: 'retail', includeChildren: true }],
    from: '2025-03-01',
    status: 'active',
    note: 'Retail division read-only for cost reporting.',
    modifiedBy: 'priya.raman@aurorahome.com',
    modifiedAt: '2026-06-02T15:47:00Z',
  },
  {
    id: 'm3',
    groupId: 'g4',
    role: 'finops-admin',
    scopes: [{ nodeId: 'retail-ecom', includeChildren: false }],
    from: '2025-09-15',
    status: 'active',
    modifiedBy: 'tom.aldridge@aurorahome.com',
    modifiedAt: '2026-02-21T11:03:00Z',
  },
  {
    id: 'm4',
    groupId: 'g5',
    role: 'contributor',
    scopes: [{ nodeId: 'wholesale', includeChildren: true }],
    from: '2025-11-01',
    status: 'active',
    note: 'Wholesale ops team — edit access for trade pricing nodes.',
    modifiedBy: 'tom.aldridge@aurorahome.com',
    modifiedAt: '2026-01-09T08:30:00Z',
  },
  {
    id: 'm5',
    groupId: 'g6',
    role: 'viewer',
    scopes: [{ nodeId: 'corp-finance', includeChildren: false }],
    from: '2026-07-01',
    to: '2026-09-30',
    status: 'active',
    note: 'Temporary access for Q3 external audit engagement (KPMG).',
    modifiedBy: 'priya.raman@aurorahome.com',
    modifiedAt: '2026-06-28T16:20:00Z',
  },
  {
    id: 'm6',
    groupId: 'g7',
    role: 'viewer',
    scopes: [{ nodeId: 'digital', includeChildren: true }],
    from: '2026-09-01',
    status: 'scheduled',
    modifiedBy: 'marta.oyelaran@aurorahome.com',
    modifiedAt: '2026-08-01T10:05:00Z',
  },
  {
    id: 'm7',
    groupId: 'g8',
    role: 'viewer',
    scopes: [{ nodeId: 'corp-legal', includeChildren: false }],
    from: '2024-04-01',
    to: '2026-03-31',
    status: 'inactive',
    note: 'E-discovery review — access ended at completion of case.',
    modifiedBy: 'marta.oyelaran@aurorahome.com',
    modifiedAt: '2026-03-31T17:00:00Z',
  },
  {
    id: 'm8',
    groupId: 'g9',
    role: 'finops-admin',
    scopes: [{ nodeId: 'digital-data', includeChildren: true }],
    from: '2025-06-12',
    status: 'orphaned',
    modifiedBy: 'tom.aldridge@aurorahome.com',
    modifiedAt: '2025-06-12T13:44:00Z',
  },
]

export type Person = {
  name: string
  email: string
  title: string
  groups: string[]
}

export const PEOPLE: Person[] = [
  { name: 'Priya Raman', email: 'priya.raman@aurorahome.com', title: 'Head of FinOps', groups: ['g1', 'g2'] },
  { name: 'Tom Aldridge', email: 'tom.aldridge@aurorahome.com', title: 'Platform Lead', groups: ['g1', 'g4'] },
  { name: 'Marta Oyelaran', email: 'marta.oyelaran@aurorahome.com', title: 'Finance Controller', groups: ['g2'] },
  { name: 'Devi Kulkarni', email: 'devi.kulkarni@aurorahome.com', title: 'Retail Analyst', groups: ['g3'] },
  { name: 'Callum Frost', email: 'callum.frost@aurorahome.com', title: 'E-commerce Engineer', groups: ['g3', 'g4'] },
  { name: 'Ines Bauer', email: 'ines.bauer@aurorahome.com', title: 'Wholesale Director', groups: ['g5'] },
  { name: 'Hana Sato', email: 'hana.sato@aurorahome.com', title: 'SRE', groups: ['g7'] },
  { name: 'Jonas Lindqvist', email: 'jonas.lindqvist@aurorahome.com', title: 'Contractor, KPMG', groups: ['g6'] },
  { name: 'Amara Nwosu', email: 'amara.nwosu@aurorahome.com', title: 'Counsel', groups: ['g8'] },
  {
    name: 'Sébastien Roche',
    email: 'sebastien.roche@aurorahome.com',
    title: 'Data Engineer',
    groups: ['g1', 'g7', 'g4', 'g3', 'g5', 'g2', 'g6'],
  },
]

export const HUB_VERSION = '4.11.2'
export const CURRENT_USER = 'priya.raman@aurorahome.com'
export const GROUP_CLAIM_LIMIT = 6

export const money = (n: number) =>
  '$' + n.toLocaleString('en-US', { maximumFractionDigits: 0 })

export const shortDate = (iso: string) =>
  new Date(iso).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })

export const stamp = (iso: string) =>
  new Date(iso).toLocaleString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
