import { useEffect, useState } from 'react'
import { HUB_VERSION, INITIAL_MAPPINGS, type Mapping } from './data'
import MappingList from './components/MappingList'
import MappingPanel from './components/MappingPanel'
import AuditView from './components/AuditView'
import FirstRun from './components/FirstRun'
import { Chip } from './components/ui'

type Screen = 'mappings' | 'audit' | 'firstrun'

const NAV: { id: string; label: string; screen?: Screen; icon: string }[] = [
  { id: 'overview', label: 'Overview', icon: 'M3 3h7v7H3zM14 3h7v4h-7zM14 11h7v10h-7zM3 14h7v7H3z' },
  { id: 'vendors', label: 'Vendors', icon: 'M4 20V10M10 20V4M16 20v-7M22 20H2' },
  { id: 'ownership', label: 'Ownership', icon: 'M12 3v4M6 21v-4a3 3 0 013-3h6a3 3 0 013 3v4M12 7a3 3 0 100 6 3 3 0 000-6z' },
  { id: 'unit', label: 'Unit economics', icon: 'M13 2L4 14h7l-1 8 9-12h-7l1-8z' },
  { id: 'budgets', label: 'Budgets', icon: 'M3 6h18v12H3zM3 10h18' },
  { id: 'seats', label: 'Seats & licenses', icon: 'M4 20v-2a4 4 0 014-4h4a4 4 0 014 4v2M10 4a4 4 0 100 8 4 4 0 000-8zM18 8h4M20 6v4' },
  { id: 'optimization', label: 'Optimization', icon: 'M12 4v16M4 12h16' },
  { id: 'orgsetup', label: 'Org setup', icon: 'M12 3v6M6 21v-6M18 21v-6M4 9h16v6H4z' },
  { id: 'mappings', label: 'Access mapping', screen: 'mappings', icon: 'M9 7h10M9 12h10M9 17h10M4 7h.01M4 12h.01M4 17h.01' },
  { id: 'firstrun', label: 'Onboarding', screen: 'firstrun', icon: 'M4 5h16v14H4zM8 9h8M8 13h5' },
  { id: 'guide', label: 'User guide', icon: 'M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3z' },
]

const TITLES: Record<Screen, { crumb: string; title: string }> = {
  mappings: { crumb: 'Org setup · Access control', title: 'Access mapping' },
  audit: { crumb: 'Org setup · Access control', title: 'Who can see what' },
  firstrun: { crumb: 'Org setup · Onboarding', title: 'First-run setup' },
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('mappings')
  const [mappings, setMappings] = useState<Mapping[]>(INITIAL_MAPPINGS)
  const [panel, setPanel] = useState<{ open: boolean; editing: Mapping | null }>({ open: false, editing: null })
  const [loading, setLoading] = useState(true)
  const [idpOnline, setIdpOnline] = useState(true)
  const [mode, setMode] = useState<'Demo' | 'Live'>('Demo')

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 900)
    return () => clearTimeout(t)
  }, [])

  const save = (m: Omit<Mapping, 'id'> & { id?: string }) => {
    setMappings((prev) =>
      m.id
        ? prev.map((x) => (x.id === m.id ? ({ ...m, id: m.id } as Mapping) : x))
        : [...prev, { ...m, id: `m${Date.now()}` } as Mapping],
    )
    setPanel({ open: false, editing: null })
  }

  const deactivate = (m: Mapping) =>
    setMappings((prev) =>
      prev.map((x) =>
        x.id === m.id
          ? {
              ...x,
              status: 'inactive',
              to: '2026-08-06',
              modifiedBy: 'priya.raman@aurorahome.com',
              modifiedAt: new Date().toISOString(),
            }
          : x,
      ),
    )

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <aside className="sticky top-0 hidden h-screen w-[228px] shrink-0 flex-col border-r border-border bg-card lg:flex">
        <div className="flex items-center gap-2.5 px-4 py-4">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-green-deep text-white">
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.2">
              <path d="M3 16l5-6 4 4 5-8 4 5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          <span>
            <span className="block text-[14px] font-semibold leading-tight text-foreground">AI Cost Hub</span>
            <span className="block text-[11px] text-muted-foreground">Aurora Home Systems</span>
          </span>
        </div>

        <div className="label px-4 pb-1.5 pt-2">Workspace</div>
        <nav className="flex-1 overflow-y-auto px-2 pb-4">
          {NAV.map((item) => {
            const active = item.screen === screen
            const disabled = !item.screen
            return (
              <button
                key={item.id}
                disabled={disabled}
                onClick={() => item.screen && setScreen(item.screen)}
                title={disabled ? 'Not part of this prototype' : undefined}
                className={`mb-0.5 flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[13px] transition-colors ${
                  active
                    ? 'bg-green-tint font-semibold text-green-deep'
                    : disabled
                      ? 'text-muted-foreground/70 hover:bg-muted'
                      : 'text-secondary-foreground hover:bg-muted hover:text-foreground'
                }`}
              >
                <svg
                  viewBox="0 0 24 24"
                  className="h-4 w-4 shrink-0"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.7"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d={item.icon} />
                </svg>
                {item.label}
              </button>
            )
          })}
        </nav>

        <div className="border-t border-border px-4 py-3">
          <div className="label">Prototype states</div>
          <div className="mt-2 grid gap-1.5">
            {[
              ['Loading', loading, () => setLoading((v) => !v)],
              ['IdP unreachable', !idpOnline, () => setIdpOnline((v) => !v)],
              [
                'Empty (no mappings)',
                mappings.length === 0,
                () => setMappings((m) => (m.length ? [] : INITIAL_MAPPINGS)),
              ],
            ].map(([label, on, fn]) => (
              <button
                key={label as string}
                onClick={fn as () => void}
                className="flex items-center gap-2 text-left text-[11.5px] text-muted-foreground hover:text-foreground"
              >
                <span
                  className={`flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-[4px] border text-[9px] text-white ${
                    on ? 'border-green-deep bg-green-deep' : 'border-[#c9c9c1] bg-white'
                  }`}
                >
                  {on ? '✓' : ''}
                </span>
                {label as string}
              </button>
            ))}
          </div>
          <div className="mt-3 text-[10.5px] leading-relaxed text-muted-foreground">
            FOCUS-aligned cost model
            <br />
            MCP-grounded copilot
          </div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-20 flex flex-wrap items-center gap-2 border-b border-border bg-card px-5 py-3">
          <div className="mr-auto min-w-0">
            <div className="text-[11.5px] text-muted-foreground">{TITLES[screen].crumb}</div>
            <h1 className="text-[19px] font-semibold tracking-tight text-foreground">{TITLES[screen].title}</h1>
          </div>

          <div className="flex h-9 items-center gap-2 rounded-full border border-border bg-card pl-1.5 pr-3">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-tint text-[10px] font-semibold text-primary">
              PR
            </span>
            <span className="leading-tight">
              <span className="block text-[12.5px] font-medium text-foreground">Priya Raman</span>
              <span className="block text-[10px] uppercase tracking-wide text-muted-foreground">Hub admin</span>
            </span>
          </div>

          <div className="flex gap-0.5 rounded-full border border-border bg-muted p-0.5">
            {(['Demo', 'Live'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`h-7 rounded-full px-3 text-[12px] font-medium transition-colors ${
                  mode === m ? 'bg-green-deep text-white' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {m}
              </button>
            ))}
          </div>

          <Chip>
            <span className={`h-1.5 w-1.5 rounded-full ${idpOnline ? 'bg-green' : 'bg-danger'}`} />
            {idpOnline ? 'IdP connected' : 'IdP unreachable'}
          </Chip>
          <Chip>Hub v{HUB_VERSION}</Chip>
          <Chip active>Aurora (full org)</Chip>
        </header>

        <main className="flex-1 px-5 py-5 lg:px-7 lg:py-6">
          {screen === 'mappings' && (
            <MappingList
              mappings={mappings}
              loading={loading}
              idpOnline={idpOnline}
              onAdd={() => setPanel({ open: true, editing: null })}
              onEdit={(m) => setPanel({ open: true, editing: m })}
              onDeactivate={deactivate}
              onFix={(m) => setPanel({ open: true, editing: m })}
            />
          )}
          {screen === 'audit' && <AuditView mappings={mappings} />}
          {screen === 'firstrun' && <FirstRun onDone={() => setScreen('mappings')} />}
        </main>
      </div>

      {panel.open && (
        <MappingPanel
          editing={panel.editing}
          mappings={mappings}
          idpOnline={idpOnline}
          onClose={() => setPanel({ open: false, editing: null })}
          onSave={save}
        />
      )}
    </div>
  )
}
