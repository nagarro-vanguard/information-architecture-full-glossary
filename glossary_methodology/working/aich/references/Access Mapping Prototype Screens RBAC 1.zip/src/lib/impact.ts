import { descendantsOf, findNode, type Mapping } from '../data'

export type Scope = { nodeId: string; includeChildren: boolean }

export function resolveScope(scopes: Scope[]): string[] {
  const ids = new Set<string>()
  for (const s of scopes) {
    ids.add(s.nodeId)
    if (s.includeChildren) descendantsOf(s.nodeId).forEach((n) => ids.add(n.id))
  }
  return [...ids]
}

export function impactOf(scopes: Scope[], members: number) {
  const ids = resolveScope(scopes)
  const roots = new Set(scopes.map((s) => s.nodeId))
  // Spend already rolls up, so only count the top of each selected branch.
  const spend = scopes.reduce((sum, s) => {
    const node = findNode(s.nodeId)
    if (!node) return sum
    return sum + (s.includeChildren ? node.monthlySpend : node.monthlySpend - (node.children ?? []).reduce((a, c) => a + c.monthlySpend, 0))
  }, 0)
  return {
    nodeIds: ids,
    nodeCount: ids.length,
    childCount: ids.length - roots.size,
    members,
    spend,
  }
}

export function overlaps(a: Scope[], b: Scope[]): string[] {
  const ra = new Set(resolveScope(a))
  return resolveScope(b).filter((id) => ra.has(id))
}

export function isLive(m: Mapping, asOf: string): boolean {
  if (m.status === 'orphaned') return false
  if (m.from > asOf) return false
  if (m.to && m.to < asOf) return false
  return true
}
